"""Tests for zdrovena.common.retry."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
import requests

from zdrovena.common.retry import retry_request


class TestRetryRequestSuccess:
    def test_first_attempt_success(self):
        session = MagicMock(spec=requests.Session)
        mock_resp = MagicMock(spec=requests.Response)
        mock_resp.raise_for_status = MagicMock()
        session.request.return_value = mock_resp

        result = retry_request(session, "GET", "https://example.com/api")

        assert result is mock_resp
        session.request.assert_called_once()

    def test_passes_kwargs_to_session(self):
        session = MagicMock(spec=requests.Session)
        mock_resp = MagicMock(spec=requests.Response)
        mock_resp.raise_for_status = MagicMock()
        session.request.return_value = mock_resp

        retry_request(
            session, "POST", "https://example.com/api",
            json={"key": "value"},
            headers={"X-Custom": "yes"},
            timeout=10,
        )

        call_kwargs = session.request.call_args
        assert call_kwargs[1]["json"] == {"key": "value"}
        assert call_kwargs[1]["headers"] == {"X-Custom": "yes"}


class TestRetryRequestFailure:
    @patch("zdrovena.common.retry.time.sleep")
    def test_retries_on_request_exception(self, mock_sleep):
        session = MagicMock(spec=requests.Session)
        session.request.side_effect = requests.ConnectionError("refused")

        with pytest.raises(RuntimeError, match="HTTP request failed after 3 attempts"):
            retry_request(
                session, "GET", "https://example.com/api",
                max_retries=3, initial_delay=0.1,
            )

        assert session.request.call_count == 3

    @patch("zdrovena.common.retry.time.sleep")
    def test_retries_on_http_error(self, mock_sleep):
        session = MagicMock(spec=requests.Session)
        mock_resp = MagicMock(spec=requests.Response)
        mock_resp.status_code = 500
        mock_resp.raise_for_status.side_effect = requests.HTTPError("500 Server Error")
        session.request.return_value = mock_resp

        with pytest.raises(RuntimeError):
            retry_request(
                session, "GET", "https://example.com/api",
                max_retries=2, initial_delay=0.01,
            )

        assert session.request.call_count == 2

    @patch("zdrovena.common.retry.time.sleep")
    def test_exponential_backoff(self, mock_sleep):
        session = MagicMock(spec=requests.Session)
        session.request.side_effect = requests.ConnectionError("refused")

        with pytest.raises(RuntimeError):
            retry_request(
                session, "GET", "https://example.com/api",
                max_retries=4, initial_delay=1.0,
            )

        # Should sleep between attempts: 1.0, 2.0, 4.0 (not after last)
        assert mock_sleep.call_count == 3
        delays = [call.args[0] for call in mock_sleep.call_args_list]
        assert delays == [1.0, 2.0, 4.0]

    @patch("zdrovena.common.retry.time.sleep")
    def test_succeeds_after_retries(self, mock_sleep):
        session = MagicMock(spec=requests.Session)
        fail_resp = MagicMock(spec=requests.Response)
        fail_resp.raise_for_status.side_effect = requests.HTTPError("503")

        ok_resp = MagicMock(spec=requests.Response)
        ok_resp.raise_for_status = MagicMock()

        session.request.side_effect = [
            requests.ConnectionError("refused"),
            ok_resp,
        ]

        result = retry_request(
            session, "GET", "https://example.com/api",
            max_retries=3, initial_delay=0.01,
        )

        assert result is ok_resp
        assert session.request.call_count == 2


class TestRetryRequestCaller:
    @patch("zdrovena.common.retry.time.sleep")
    def test_caller_in_error_message(self, mock_sleep):
        session = MagicMock(spec=requests.Session)
        session.request.side_effect = requests.ConnectionError("refused")

        with pytest.raises(RuntimeError, match="Fakturownia"):
            retry_request(
                session, "GET", "https://example.com/api",
                max_retries=1, caller="Fakturownia",
            )

    @patch("zdrovena.common.retry.time.sleep")
    def test_no_caller_in_error_message(self, mock_sleep):
        session = MagicMock(spec=requests.Session)
        session.request.side_effect = requests.ConnectionError("refused")

        with pytest.raises(RuntimeError, match="^HTTP request failed"):
            retry_request(
                session, "GET", "https://example.com/api",
                max_retries=1, caller="",
            )
